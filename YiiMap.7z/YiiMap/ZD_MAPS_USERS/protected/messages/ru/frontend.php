<?php
return array(
    'CREATE_PLACE' => 'Создать объект',
    'UPDATE_PLACE' => 'Изменить объект',
    'TITLE' => 'Название',
    'FIELD_NOT_EMPTY' => 'Это поле не может быть пустым',
    'DESCRIPTION' => 'Описание',
    'ENABLED' => 'включен',
    'LATITUDE' => 'Широта',
    'CLICK_ON_THE_MAP' => 'Кликните по карте',
    'LONGITUDE' => 'Долгота',
    'ERRORS' => 'Ошибки',
    'CANCEL' => 'Отмена',
    'DELETE' => 'Удалить',
    'UPDATE' => 'Изменить',
    'NO_PLACES' => 'Нет объектов',
    'ADD_PLACE' => 'Добавить объект',
);