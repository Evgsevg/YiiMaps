<?php
return array(
    'CREATE_PLACE' => 'Create place',
    'UPDATE_PLACE' => 'Update place',
    'TITLE' => 'Title',
    'FIELD_NOT_EMPTY' => 'This field shouldn\'t be empty',
    'DESCRIPTION' => 'Description',
    'ENABLED' => 'enabled',
    'LATITUDE' => 'Latitude',
    'CLICK_ON_THE_MAP' => 'Click on the map',
    'LONGITUDE' => 'Longitude',
    'ERRORS' => 'Errors',
    'CREATE' => 'Create',
    'CANCEL' => 'Cancel',
    'DELETE' => 'Delete',
    'UPDATE' => 'Update',
    'NO_PLACES' => 'No places',
    'ADD_PLACE' => 'Add place',
);