var lang = 'en_us';
var translations = [];