<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - О сервисе';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>О сервисе</h1>

<p>Personal maps – это демонстрационное приложение, предназначенное для того, чтобы показать использование фреймворков Yii2 и AngularJS.</p>
<p>Исходный код вы можете скачать на <a href="https://www.http://zruchnadostavka.ua/">GitHub</a>.</p>
<p>Описание принципов работы размещено в <a href="http://www.http://zruchnadostavka.ua/.html">моём блоге</a>.</p>
